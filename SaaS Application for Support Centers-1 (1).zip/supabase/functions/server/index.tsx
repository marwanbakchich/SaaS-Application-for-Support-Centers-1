import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Create Supabase client
const getSupabaseClient = () => {
  return createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );
};

// Health check
app.get('/make-server-56cffd48/health', (c) => {
  return c.json({ status: 'ok', message: 'Server is running' });
});

// Sign up endpoint
app.post('/make-server-56cffd48/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: 'البريد الإلكتروني، كلمة المرور والاسم مطلوبة' }, 400);
    }

    const supabase = getSupabaseClient();

    // Create user with admin API
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message || 'فشل إنشاء الحساب' }, 400);
    }

    return c.json({
      success: true,
      message: 'تم إنشاء الحساب بنجاح',
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata.name,
      },
    });
  } catch (error) {
    console.log('Signup error:', error);
    return c.json({ error: 'حدث خطأ في السيرفر' }, 500);
  }
});

// Sign in endpoint
app.post('/make-server-56cffd48/auth/signin', async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبان' }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.log('Signin error:', error);
      return c.json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' }, 401);
    }

    return c.json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح',
      access_token: data.session.access_token,
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name,
      },
    });
  } catch (error) {
    console.log('Signin error:', error);
    return c.json({ error: 'حدث خطأ في السيرفر' }, 500);
  }
});

// Get current user
app.get('/make-server-56cffd48/auth/me', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'غير مصرح' }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const { data, error } = await supabase.auth.getUser(accessToken);

    if (error || !data.user) {
      return c.json({ error: 'غير مصرح' }, 401);
    }

    return c.json({
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name,
      },
    });
  } catch (error) {
    console.log('Get user error:', error);
    return c.json({ error: 'حدث خطأ في السيرفر' }, 500);
  }
});

// Sign out endpoint
app.post('/make-server-56cffd48/auth/signout', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    const accessToken = authHeader?.split(' ')[1];

    if (!accessToken) {
      return c.json({ error: 'غير مصرح' }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const { error } = await supabase.auth.signOut();

    if (error) {
      console.log('Signout error:', error);
      return c.json({ error: 'فشل تسجيل الخروج' }, 400);
    }

    return c.json({
      success: true,
      message: 'تم تسجيل الخروج بنجاح',
    });
  } catch (error) {
    console.log('Signout error:', error);
    return c.json({ error: 'حدث خطأ في السيرفر' }, 500);
  }
});

Deno.serve(app.fetch);
