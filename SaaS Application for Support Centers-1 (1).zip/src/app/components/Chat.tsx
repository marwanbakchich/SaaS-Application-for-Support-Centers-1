import { useState } from 'react';
import { Send, Paperclip, Smile, Search, MoreVertical, Phone, Video, Circle } from 'lucide-react';

interface Message {
  id: number;
  senderId: number;
  text: string;
  time: string;
  isOwn: boolean;
}

interface Conversation {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
  type: 'student' | 'teacher' | 'group';
}

export function Chat() {
  const [selectedConversation, setSelectedConversation] = useState<number>(1);
  const [messageText, setMessageText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const conversations: Conversation[] = [
    {
      id: 1,
      name: 'Ahmed Mohamed',
      avatar: 'AM',
      lastMessage: 'Can we reschedule tomorrow\'s session?',
      time: '5m ago',
      unread: 2,
      online: true,
      type: 'teacher',
    },
    {
      id: 2,
      name: 'Mathematics Group',
      avatar: 'MG',
      lastMessage: 'New assignment uploaded',
      time: '1h ago',
      unread: 5,
      online: false,
      type: 'group',
    },
    {
      id: 3,
      name: 'Sarah Ahmed',
      avatar: 'SA',
      lastMessage: 'Thank you for the help!',
      time: '2h ago',
      unread: 0,
      online: true,
      type: 'student',
    },
    {
      id: 4,
      name: 'Fatima Zahra',
      avatar: 'FZ',
      lastMessage: 'I have a question about the lesson',
      time: '3h ago',
      unread: 1,
      online: false,
      type: 'teacher',
    },
    {
      id: 5,
      name: 'Physics Study Group',
      avatar: 'PG',
      lastMessage: 'See you in the next session',
      time: '5h ago',
      unread: 0,
      online: false,
      type: 'group',
    },
  ];

  const messages: Message[] = [
    {
      id: 1,
      senderId: 1,
      text: 'Hello! I wanted to discuss tomorrow\'s session.',
      time: '10:30 AM',
      isOwn: false,
    },
    {
      id: 2,
      senderId: 0,
      text: 'Hi Ahmed! Sure, what would you like to discuss?',
      time: '10:32 AM',
      isOwn: true,
    },
    {
      id: 3,
      senderId: 1,
      text: 'Can we reschedule tomorrow\'s session? I have an emergency.',
      time: '10:33 AM',
      isOwn: false,
    },
    {
      id: 4,
      senderId: 0,
      text: 'Of course! Would Friday at the same time work for you?',
      time: '10:35 AM',
      isOwn: true,
    },
    {
      id: 5,
      senderId: 1,
      text: 'Yes, Friday works perfectly. Thank you for understanding!',
      time: '10:36 AM',
      isOwn: false,
    },
  ];

  const selectedConv = conversations.find(c => c.id === selectedConversation);

  const handleSendMessage = () => {
    if (messageText.trim()) {
      // Here you would send the message to your backend
      console.log('Sending message:', messageText);
      setMessageText('');
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'teacher': return 'from-purple-500 to-purple-600';
      case 'student': return 'from-blue-500 to-blue-600';
      case 'group': return 'from-green-500 to-green-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="h-[calc(100vh-120px)] flex gap-6">
      {/* Conversations List */}
      <div className="w-80 bg-white rounded-xl border border-gray-200 flex flex-col">
        {/* Search */}
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto">
          {conversations
            .filter(conv => conv.name.toLowerCase().includes(searchQuery.toLowerCase()))
            .map((conv) => (
              <button
                key={conv.id}
                onClick={() => setSelectedConversation(conv.id)}
                className={`w-full p-4 flex items-start gap-3 hover:bg-gray-50 transition-colors border-b border-gray-100 ${
                  selectedConversation === conv.id ? 'bg-blue-50' : ''
                }`}
              >
                <div className="relative">
                  <div className={`w-12 h-12 bg-gradient-to-br ${getTypeColor(conv.type)} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <span className="text-white font-semibold">{conv.avatar}</span>
                  </div>
                  {conv.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                  )}
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-gray-900 truncate">{conv.name}</h4>
                    <span className="text-xs text-gray-500">{conv.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
                </div>
                {conv.unread > 0 && (
                  <div className="bg-blue-600 text-white text-xs font-semibold px-2 py-1 rounded-full min-w-[20px] text-center">
                    {conv.unread}
                  </div>
                )}
              </button>
            ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 bg-white rounded-xl border border-gray-200 flex flex-col">
        {selectedConv ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className={`w-10 h-10 bg-gradient-to-br ${getTypeColor(selectedConv.type)} rounded-full flex items-center justify-center`}>
                    <span className="text-white font-semibold text-sm">{selectedConv.avatar}</span>
                  </div>
                  {selectedConv.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{selectedConv.name}</h3>
                  <p className="text-sm text-gray-500">
                    {selectedConv.online ? 'Online' : 'Offline'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                  <Phone className="w-5 h-5" />
                </button>
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                  <Video className="w-5 h-5" />
                </button>
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[70%] ${message.isOwn ? 'order-2' : 'order-1'}`}>
                    <div
                      className={`rounded-2xl px-4 py-2 ${
                        message.isOwn
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="text-sm">{message.text}</p>
                    </div>
                    <p className={`text-xs text-gray-500 mt-1 ${message.isOwn ? 'text-right' : 'text-left'}`}>
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-end gap-2">
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                  <Paperclip className="w-5 h-5" />
                </button>
                <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                  <Smile className="w-5 h-5" />
                </button>
                <div className="flex-1">
                  <textarea
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="Type a message..."
                    className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all resize-none"
                    rows={1}
                  />
                </div>
                <button
                  onClick={handleSendMessage}
                  className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!messageText.trim()}
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <p>Select a conversation to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
}
