import { useState } from 'react';
import { Plus, Search, Filter, Clock, User, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';

interface Ticket {
  id: number;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in-progress' | 'resolved';
  assignee: string;
  reporter: string;
  createdAt: string;
  category: string;
}

export function SupportTickets() {
  const [tickets, setTickets] = useState<Ticket[]>([
    {
      id: 1,
      title: 'Cannot access online session',
      description: 'Student unable to join the online mathematics class',
      priority: 'high',
      status: 'open',
      assignee: 'Ahmed Mohamed',
      reporter: 'Sarah Ahmed',
      createdAt: '2h ago',
      category: 'Technical',
    },
    {
      id: 2,
      title: 'Payment issue',
      description: 'Payment for the new semester not reflected',
      priority: 'urgent',
      status: 'open',
      assignee: 'Fatima Zahra',
      reporter: 'Ali Hassan',
      createdAt: '1h ago',
      category: 'Billing',
    },
    {
      id: 3,
      title: 'Schedule change request',
      description: 'Need to reschedule physics session to next week',
      priority: 'medium',
      status: 'in-progress',
      assignee: 'Youssef Alaoui',
      reporter: 'Mohamed Riad',
      createdAt: '4h ago',
      category: 'Scheduling',
    },
    {
      id: 4,
      title: 'Missing course materials',
      description: 'Chemistry lab manual not available in resources',
      priority: 'low',
      status: 'in-progress',
      assignee: 'Sara Ahmed',
      reporter: 'Nour Eddine',
      createdAt: '6h ago',
      category: 'Resources',
    },
    {
      id: 5,
      title: 'Grade dispute',
      description: 'Student questioning the grade on recent test',
      priority: 'medium',
      status: 'resolved',
      assignee: 'Ahmed Mohamed',
      reporter: 'Hiba Mansouri',
      createdAt: '1d ago',
      category: 'Academic',
    },
    {
      id: 6,
      title: 'Account access issue',
      description: 'Cannot login to student portal',
      priority: 'high',
      status: 'resolved',
      assignee: 'IT Support',
      reporter: 'Karim Bennani',
      createdAt: '2d ago',
      category: 'Technical',
    },
  ]);

  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open': return <AlertCircle className="w-5 h-5 text-blue-600" />;
      case 'in-progress': return <Clock className="w-5 h-5 text-orange-600" />;
      case 'resolved': return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      default: return <AlertCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  const columns = [
    { id: 'open', title: 'Open', color: 'blue' },
    { id: 'in-progress', title: 'In Progress', color: 'orange' },
    { id: 'resolved', title: 'Resolved', color: 'green' },
  ];

  const getTicketsByStatus = (status: string) => {
    return tickets.filter(ticket => ticket.status === status);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Support Tickets</h1>
          <p className="text-gray-600">Manage and track support requests</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-5 h-5" />
          <span>New Ticket</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-4">
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search tickets..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Filter className="w-4 h-4" />
          <span>Filters</span>
        </button>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {columns.map((column) => {
          const columnTickets = getTicketsByStatus(column.id);
          return (
            <div key={column.id} className="bg-gray-50 rounded-xl p-4">
              {/* Column Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 bg-${column.color}-500 rounded-full`} />
                  <h3 className="font-semibold text-gray-900">{column.title}</h3>
                  <span className="px-2 py-0.5 bg-gray-200 text-gray-700 text-xs font-medium rounded-full">
                    {columnTickets.length}
                  </span>
                </div>
              </div>

              {/* Tickets */}
              <div className="space-y-3">
                {columnTickets.map((ticket) => (
                  <button
                    key={ticket.id}
                    onClick={() => setSelectedTicket(ticket)}
                    className="w-full bg-white rounded-lg p-4 border border-gray-200 hover:shadow-md transition-all text-left"
                  >
                    {/* Priority Badge */}
                    <div className="flex items-center justify-between mb-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium border ${getPriorityColor(ticket.priority)}`}>
                        {ticket.priority.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-500">{ticket.createdAt}</span>
                    </div>

                    {/* Title */}
                    <h4 className="font-semibold text-gray-900 mb-2">{ticket.title}</h4>

                    {/* Description */}
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                      {ticket.description}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs font-semibold">
                            {ticket.assignee.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <span className="text-xs text-gray-600">{ticket.assignee}</span>
                      </div>
                      <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                        {ticket.category}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Add Card Button */}
              <button className="w-full mt-3 p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" />
                <span className="text-sm">Add ticket</span>
              </button>
            </div>
          );
        })}
      </div>

      {/* Ticket Details Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  {getStatusIcon(selectedTicket.status)}
                  <h2 className="text-2xl font-bold text-gray-900">{selectedTicket.title}</h2>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded text-sm font-medium border ${getPriorityColor(selectedTicket.priority)}`}>
                    {selectedTicket.priority.toUpperCase()}
                  </span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded">
                    {selectedTicket.category}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedTicket(null)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="space-y-6">
              {/* Description */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                <p className="text-gray-600">{selectedTicket.description}</p>
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Assignee</h4>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-semibold">
                        {selectedTicket.assignee.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <span className="text-gray-900">{selectedTicket.assignee}</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Reporter</h4>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-semibold">
                        {selectedTicket.reporter.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <span className="text-gray-900">{selectedTicket.reporter}</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Status</h4>
                  <span className="text-gray-900 capitalize">{selectedTicket.status.replace('-', ' ')}</span>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Created</h4>
                  <span className="text-gray-900">{selectedTicket.createdAt}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => setSelectedTicket(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Update Ticket
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
