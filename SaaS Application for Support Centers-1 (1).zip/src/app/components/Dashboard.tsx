import { 
  Users, 
  GraduationCap, 
  Calendar, 
  Headphones,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export function Dashboard() {
  const stats = [
    {
      label: 'Total Students',
      value: '324',
      change: '+12.5%',
      trend: 'up',
      icon: GraduationCap,
      color: 'blue',
      bgColor: 'bg-blue-500',
    },
    {
      label: 'Total Teachers',
      value: '48',
      change: '+8.2%',
      trend: 'up',
      icon: Users,
      color: 'purple',
      bgColor: 'bg-purple-500',
    },
    {
      label: 'Sessions Today',
      value: '12',
      change: '+5.4%',
      trend: 'up',
      icon: Calendar,
      color: 'green',
      bgColor: 'bg-green-500',
    },
    {
      label: 'Open Tickets',
      value: '7',
      change: '-3.1%',
      trend: 'down',
      icon: Headphones,
      color: 'orange',
      bgColor: 'bg-orange-500',
    },
  ];

  const studentGrowthData = [
    { month: 'Jan', students: 180 },
    { month: 'Feb', students: 220 },
    { month: 'Mar', students: 250 },
    { month: 'Apr', students: 280 },
    { month: 'May', students: 300 },
    { month: 'Jun', students: 324 },
  ];

  const sessionsData = [
    { day: 'Mon', sessions: 8 },
    { day: 'Tue', sessions: 12 },
    { day: 'Wed', sessions: 10 },
    { day: 'Thu', sessions: 15 },
    { day: 'Fri', sessions: 9 },
    { day: 'Sat', sessions: 14 },
    { day: 'Sun', sessions: 11 },
  ];

  const attendanceData = [
    { name: 'Present', value: 285, color: '#10b981' },
    { name: 'Absent', value: 25, color: '#ef4444' },
    { name: 'Late', value: 14, color: '#f59e0b' },
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'student',
      text: 'Sarah Ahmed joined Mathematics Advanced group',
      time: '5 minutes ago',
      icon: GraduationCap,
      color: 'blue',
    },
    {
      id: 2,
      type: 'session',
      text: 'New session scheduled for Physics tomorrow at 2 PM',
      time: '30 minutes ago',
      icon: Calendar,
      color: 'green',
    },
    {
      id: 3,
      type: 'teacher',
      text: 'Ahmed Mohamed uploaded new resource',
      time: '1 hour ago',
      icon: Users,
      color: 'purple',
    },
    {
      id: 4,
      type: 'ticket',
      text: 'Support ticket #1234 has been resolved',
      time: '2 hours ago',
      icon: CheckCircle2,
      color: 'green',
    },
  ];

  const upcomingSessions = [
    {
      id: 1,
      subject: 'Mathematics Advanced',
      teacher: 'Ahmed Mohamed',
      time: 'Today, 4:00 PM',
      students: 18,
      status: 'upcoming',
    },
    {
      id: 2,
      subject: 'Physics Basics',
      teacher: 'Fatima Zahra',
      time: 'Today, 6:00 PM',
      students: 15,
      status: 'upcoming',
    },
    {
      id: 3,
      subject: 'Arabic Language',
      teacher: 'Youssef Alaoui',
      time: 'Tomorrow, 10:00 AM',
      students: 22,
      status: 'scheduled',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 ${stat.bgColor} rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`flex items-center gap-1 text-sm font-semibold ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  <span>{stat.change}</span>
                </div>
              </div>
              <div>
                <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Student Growth Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-gray-900">Student Growth</h3>
              <p className="text-sm text-gray-600">Monthly student enrollment trend</p>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1">
              View Report <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={studentGrowthData}>
              <defs>
                <linearGradient id="colorStudents" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }}
              />
              <Area 
                type="monotone" 
                dataKey="students" 
                stroke="#3b82f6" 
                strokeWidth={2}
                fill="url(#colorStudents)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Attendance Pie Chart */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Today's Attendance</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={attendanceData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {attendanceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {attendanceData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-gray-600">{item.name}</span>
                </div>
                <span className="text-sm font-semibold text-gray-900">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sessions Chart */}
      <div className="bg-white rounded-xl p-6 border border-gray-200">
        <h3 className="text-lg font-bold text-gray-900 mb-6">Weekly Sessions</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={sessionsData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="day" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px'
              }}
            />
            <Bar dataKey="sessions" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Sessions */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Upcoming Sessions</h3>
          <div className="space-y-3">
            {upcomingSessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 mb-1">{session.subject}</h4>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{session.teacher}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{session.time}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    session.status === 'upcoming'
                      ? 'bg-orange-100 text-orange-600'
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    {session.students} Students
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivities.map((activity) => {
              const Icon = activity.icon;
              return (
                <div key={activity.id} className="flex items-start gap-3">
                  <div className={`p-2 bg-${activity.color}-100 rounded-lg`}>
                    <Icon className={`w-4 h-4 text-${activity.color}-600`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">{activity.text}</p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
