import { useState } from 'react';
import { Plus, Download, Eye, FileText, Video, Image, File, Search, Filter, Upload } from 'lucide-react';

interface Resource {
  id: number;
  title: string;
  type: 'pdf' | 'video' | 'image' | 'document';
  teacher: string;
  subject: string;
  uploadDate: string;
  size: string;
  downloads: number;
  thumbnail?: string;
}

export function Resources() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedType, setSelectedType] = useState<string>('all');

  const resources: Resource[] = [
    {
      id: 1,
      title: 'Calculus Chapter 5 - Integrals',
      type: 'pdf',
      teacher: 'Ahmed Mohamed',
      subject: 'Mathematics',
      uploadDate: '2 days ago',
      size: '2.4 MB',
      downloads: 45,
    },
    {
      id: 2,
      title: 'Physics Lecture - Newton\'s Laws',
      type: 'video',
      teacher: 'Fatima Zahra',
      subject: 'Physics',
      uploadDate: '1 week ago',
      size: '125 MB',
      downloads: 78,
    },
    {
      id: 3,
      title: 'Arabic Grammar Rules',
      type: 'pdf',
      teacher: 'Youssef Alaoui',
      subject: 'Arabic Language',
      uploadDate: '3 days ago',
      size: '1.8 MB',
      downloads: 32,
    },
    {
      id: 4,
      title: 'Chemistry Lab Experiment',
      type: 'video',
      teacher: 'Sara Ahmed',
      subject: 'Chemistry',
      uploadDate: '5 days ago',
      size: '89 MB',
      downloads: 56,
    },
    {
      id: 5,
      title: 'Biology Diagrams Collection',
      type: 'image',
      teacher: 'Mohamed Riad',
      subject: 'Biology',
      uploadDate: '1 week ago',
      size: '15 MB',
      downloads: 41,
    },
    {
      id: 6,
      title: 'History Timeline - 20th Century',
      type: 'document',
      teacher: 'Hiba Mansouri',
      subject: 'History',
      uploadDate: '4 days ago',
      size: '3.2 MB',
      downloads: 29,
    },
    {
      id: 7,
      title: 'Geometry Practice Problems',
      type: 'pdf',
      teacher: 'Ahmed Mohamed',
      subject: 'Mathematics',
      uploadDate: '1 day ago',
      size: '1.5 MB',
      downloads: 18,
    },
    {
      id: 8,
      title: 'English Literature Analysis',
      type: 'document',
      teacher: 'Nour Eddine',
      subject: 'English',
      uploadDate: '6 days ago',
      size: '2.1 MB',
      downloads: 37,
    },
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="w-6 h-6" />;
      case 'video': return <Video className="w-6 h-6" />;
      case 'image': return <Image className="w-6 h-6" />;
      case 'document': return <File className="w-6 h-6" />;
      default: return <File className="w-6 h-6" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'pdf': return 'bg-red-100 text-red-600';
      case 'video': return 'bg-purple-100 text-purple-600';
      case 'image': return 'bg-blue-100 text-blue-600';
      case 'document': return 'bg-green-100 text-green-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  const resourceTypes = [
    { id: 'all', label: 'All', count: resources.length },
    { id: 'pdf', label: 'PDFs', count: resources.filter(r => r.type === 'pdf').length },
    { id: 'video', label: 'Videos', count: resources.filter(r => r.type === 'video').length },
    { id: 'image', label: 'Images', count: resources.filter(r => r.type === 'image').length },
    { id: 'document', label: 'Documents', count: resources.filter(r => r.type === 'document').length },
  ];

  const filteredResources = selectedType === 'all' 
    ? resources 
    : resources.filter(r => r.type === selectedType);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Resources & Courses</h1>
          <p className="text-gray-600">Educational materials and course content</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Upload className="w-5 h-5" />
          <span>Upload Resource</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search resources..."
                className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              />
            </div>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Grid
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              List
            </button>
          </div>
        </div>

        {/* Type Filters */}
        <div className="flex gap-2">
          {resourceTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedType === type.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {type.label} ({type.count})
            </button>
          ))}
        </div>
      </div>

      {/* Resources Grid */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredResources.map((resource) => (
            <div
              key={resource.id}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              {/* Thumbnail */}
              <div className={`h-40 ${getTypeColor(resource.type)} flex items-center justify-center`}>
                {getTypeIcon(resource.type)}
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                  {resource.title}
                </h3>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-semibold">
                        {resource.teacher.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <span className="text-sm text-gray-600">{resource.teacher}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{resource.uploadDate}</span>
                    <span>{resource.size}</span>
                  </div>

                  <div className="flex items-center gap-1 text-xs text-gray-600">
                    <Download className="w-3 h-3" />
                    <span>{resource.downloads} downloads</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button className="flex-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium flex items-center justify-center gap-2">
                    <Eye className="w-4 h-4" />
                    View
                  </button>
                  <button className="flex-1 px-3 py-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors text-sm font-medium flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Resources List */
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Resource</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Teacher</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Subject</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Upload Date</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Size</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Downloads</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredResources.map((resource) => (
                <tr key={resource.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${getTypeColor(resource.type)}`}>
                        {getTypeIcon(resource.type)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{resource.title}</p>
                        <p className="text-sm text-gray-500">{resource.type.toUpperCase()}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-semibold">
                          {resource.teacher.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <span className="text-sm text-gray-900">{resource.teacher}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">{resource.subject}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{resource.uploadDate}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{resource.size}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{resource.downloads}</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
