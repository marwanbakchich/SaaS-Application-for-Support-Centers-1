import { useState } from 'react';
import { Plus, Edit2, Trash2, MapPin, Phone, Mail, X } from 'lucide-react';

interface Center {
  id: number;
  name: string;
  location: string;
  phone: string;
  email: string;
  capacity: number;
  students: number;
  teachers: number;
}

export function Centers() {
  const [centers, setCenters] = useState<Center[]>([
    {
      id: 1,
      name: 'مركز النور للدعم التعليمي',
      location: 'الدار البيضاء',
      phone: '0522-123456',
      email: 'nour@example.com',
      capacity: 100,
      students: 85,
      teachers: 8,
    },
    {
      id: 2,
      name: 'مركز الأمل للتعليم',
      location: 'الرباط',
      phone: '0537-789012',
      email: 'amal@example.com',
      capacity: 80,
      students: 65,
      teachers: 6,
    },
    {
      id: 3,
      name: 'مركز التميز التربوي',
      location: 'فاس',
      phone: '0535-345678',
      email: 'excellence@example.com',
      capacity: 120,
      students: 95,
      teachers: 10,
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCenter, setEditingCenter] = useState<Center | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    phone: '',
    email: '',
    capacity: 0,
  });

  const handleAdd = () => {
    setEditingCenter(null);
    setFormData({ name: '', location: '', phone: '', email: '', capacity: 0 });
    setIsModalOpen(true);
  };

  const handleEdit = (center: Center) => {
    setEditingCenter(center);
    setFormData({
      name: center.name,
      location: center.location,
      phone: center.phone,
      email: center.email,
      capacity: center.capacity,
    });
    setIsModalOpen(true);
  };

  const handleDelete = (id: number) => {
    setCenters(centers.filter((c) => c.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCenter) {
      setCenters(
        centers.map((c) =>
          c.id === editingCenter.id
            ? { ...c, ...formData }
            : c
        )
      );
    } else {
      const newCenter: Center = {
        id: Date.now(),
        ...formData,
        students: 0,
        teachers: 0,
      };
      setCenters([...centers, newCenter]);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">إدارة المراكز</h2>
          <p className="text-gray-600">إدارة جميع مراكز الدعم التعليمي</p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة مركز</span>
        </button>
      </div>

      {/* Centers Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {centers.map((center) => (
          <div
            key={center.id}
            className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">{center.name}</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(center)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(center.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{center.location}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Phone className="w-4 h-4" />
                <span>{center.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span>{center.email}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{center.students}</p>
                <p className="text-sm text-gray-600">طلاب</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{center.teachers}</p>
                <p className="text-sm text-gray-600">معلمين</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{center.capacity}</p>
                <p className="text-sm text-gray-600">السعة</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">
                {editingCenter ? 'تعديل المركز' : 'إضافة مركز جديد'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 text-right">
                  اسم المركز
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 text-right">
                  الموقع
                </label>
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 text-right">
                  الهاتف
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 text-right">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1 text-right">
                  السعة القصوى
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {editingCenter ? 'حفظ التعديلات' : 'إضافة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
