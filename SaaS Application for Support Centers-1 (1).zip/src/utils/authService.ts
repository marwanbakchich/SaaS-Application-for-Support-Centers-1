import { projectId, publicAnonKey } from '/utils/supabase/info';

const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-56cffd48`;

interface SignUpData {
  email: string;
  password: string;
  name: string;
}

interface SignInData {
  email: string;
  password: string;
}

interface AuthResponse {
  success: boolean;
  message?: string;
  access_token?: string;
  user?: {
    id: string;
    email: string;
    name?: string;
  };
  error?: string;
}

export const authService = {
  async signUp(data: SignUpData): Promise<AuthResponse> {
    try {
      const response = await fetch(`${API_URL}/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      
      if (!response.ok) {
        console.error('Signup error response:', result);
        throw new Error(result.error || 'فشل إنشاء الحساب');
      }

      return result;
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    }
  },

  async signIn(data: SignInData): Promise<AuthResponse> {
    try {
      const response = await fetch(`${API_URL}/auth/signin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      
      if (!response.ok) {
        console.error('Signin error response:', result);
        throw new Error(result.error || 'فشل تسجيل الدخول');
      }

      // Save token to localStorage
      if (result.access_token) {
        localStorage.setItem('access_token', result.access_token);
        localStorage.setItem('user', JSON.stringify(result.user));
      }

      return result;
    } catch (error) {
      console.error('Signin error:', error);
      throw error;
    }
  },

  async getCurrentUser(): Promise<AuthResponse> {
    try {
      const token = localStorage.getItem('access_token');
      
      if (!token) {
        throw new Error('لا يوجد رمز وصول');
      }

      const response = await fetch(`${API_URL}/auth/me`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      const result = await response.json();
      
      if (!response.ok) {
        console.error('Get user error response:', result);
        // Clear invalid token
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        throw new Error(result.error || 'غير مصرح');
      }

      return result;
    } catch (error) {
      console.error('Get user error:', error);
      throw error;
    }
  },

  async signOut(): Promise<void> {
    try {
      const token = localStorage.getItem('access_token');
      
      if (token) {
        await fetch(`${API_URL}/auth/signout`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
      }

      // Clear local storage
      localStorage.removeItem('access_token');
      localStorage.removeItem('user');
    } catch (error) {
      console.error('Signout error:', error);
      // Clear local storage even if API call fails
      localStorage.removeItem('access_token');
      localStorage.removeItem('user');
    }
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem('access_token');
  },

  getStoredUser(): { id: string; email: string; name?: string } | null {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      try {
        return JSON.parse(userStr);
      } catch {
        return null;
      }
    }
    return null;
  },
};
